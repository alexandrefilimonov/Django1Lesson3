﻿from django.shortcuts import render
import json
from mainapp.models import ProductCategory, Product

# Create your views here.
#with open("./static/data/data.json",'r', encoding='utf8') as data, \
#    open("./static/data/content_index.json",'r', encoding='utf8') as content, \
#    open("./static/data/categories.json",'r', encoding='utf8') as categories: 
#    data = json.load(data)
#    content = json.load(content) 	
#    categories = json.load(categories) 
#data["index"].update(content)
	
def main(request):
    context = { 
        'title': 'главная', 	
    }
    return render(request, 'mainapp/index.html', context) # ,data["index"])

def products(request):
    products = Product.objects.all()
    context = { 
        'title': 'каталог букетов', 
        'products': products,	
    }
    return render(request, 'mainapp/products.html', context) 

def contacts(request):
    contacts = [
		{ 
			'city': 'Москва', 	
			'phone': '+7(905)456-67-67', 	
			'email': 'magaizinzvetov@magaizinzvetov.ru', 	
			'address': '119034 г.Москва, ул.Остоженка, д.12/1', 			
		}, 
		{ 
			'city': 'Санкт-Петербург', 	
			'phone': '+7(812)956-67-67', 	
			'email': 'magaizinzvetov_spb@magaizinzvetov.ru', 	
			'address': '118034 г.Санкт-Петербург, ул.Плеханова, д.15', 			
		}		
	]
    context = { 
        'title': 'контакты', 
        'contacts': contacts, 		
    }
    return render(request, 'mainapp/contacts.html', context) 
	
def item1(request):
    products = Product.objects.filter(name="1")
    context = { 
        'title': 'букет "Подарочный"'.title(), #one of the ways to make first latter of the title as Capital; another way is - | in template 
        'products': products,		
    }
    return render(request, 'mainapp/item1.html', context) 

def item2(request):
    products = Product.objects.filter(name="2")
    context = { 
        'title': 'букет "С днем рожденья!"', 
        'products': products,		
    }
    return render(request, 'mainapp/item2.html', context) 

def item3(request):
    products = Product.objects.filter(name="3")
    context = { 
        'title': 'букет "Сюрприз!"', 	
        'products': products,
		}
    return render(request, 'mainapp/item3.html', context) 

def item4(request):
    products = Product.objects.filter(name="4")
    context = { 
        'title': 'букет "Свадебный-1"', 	
        'products': products,
		}
    return render(request, 'mainapp/item4.html', context) 

def item5(request):
    products = Product.objects.filter(name="5")
    context = { 
        'title': 'букет "Свадебный-2"', 	
        'products': products,
		}
    return render(request, 'mainapp/item5.html', context) 

